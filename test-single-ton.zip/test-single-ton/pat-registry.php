<?php
class Registry
{
	private static $instance;
	protected static $store = array();
	private function __construct()
	{
	}
	public function isValid($key)
	{
		return array_key_exists($key, Registry::$store);
	}
	public static function ins()
	{
		if(self::$instance==null)
		{
			//echo 'initializing<hr>';
			self::$instance=new Registry();
		}
		return self::$instance;
	}
	
	public function get($key)
	{
		if(array_key_exists($key, Registry::$store))
		{
			return Registry::$store[$key];
		}
	}
	
	public function set($key, $obj)
	{
		Registry::$store[$key] = $obj;
	}
}

abstract class Model extends Registry
{
	protected $name;
	public function __construct()
	{
		$this->name = $this->className();
	}
	abstract function className();
	
	public function __get($name)
	{
		return $this->$name;
	}
}

class ThisModel extends Model
{
	protected $params;
	public function className()
	{
		return __CLASS__;
	}
	public function output()
	{
		$this->params[] = "1";
		$this->params[] = "2";
		$this->params[] = "3";
		//echo $this->name;exit;
	}
	public function testObject2()
	{
		$obj=new ThisObject2();
	}
}

$obj1 = new ThisModel();
Model::ins()->set('model', $obj1);
$obj1->testObject2();
class ThisObject2
{
	public function __construct()
	{
		$this->test();
	}
	
	public function test()
	{
		print_r(Model::ins()->get('model'));
		//print_r(RegisterGlobal::ins()->model->params);exit;
	}
}

//$obj1->output();
//$obj2 = new ThisModel2();
//$obj3 = new ThisModel3();
//RegisterGlobal::ins()->insertGlobal($obj1);
//RegisterGlobal::ins()->insertGlobal($obj2);
//RegisterGlobal::ins()->insertGlobal($obj3);

//$obj2=new ThisObject2();
//$obj2->test();
/*
class ThisModel2 extends Model
{
	public function className()
	{
		return __CLASS__;
	}
	public function output()
	{
		echo $this->name;exit;
	}
}
class ThisModel3 extends Model
{
	public function className()
	{
		return __CLASS__;
	}
	public function output()
	{
		echo $this->name;exit;
	}
}
*/
?>