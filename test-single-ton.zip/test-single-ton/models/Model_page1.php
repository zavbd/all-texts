<?php
require_once('Model.php');
class Model_page1 extends Model
{
	protected $params;
	public $params_next;
	public function className()
	{
		return __CLASS__;
	}
	public function output()
	{
		$this->params[] = "1";
		$this->params[] = "2";
		$this->params[] = "3";
		//echo $this->name;exit;
		$this->setOther();
		$this->getTestObject1();
	}
	
	public function setOther()
	{
		$this->params_next=array('a'=>1,'b'=>2);
	}
	public function getTestObject1()
	{
		return new TestObject1();
	}
}

class TestObject1
{
	public function __construct()
	{
		$this->test();
	}
	
	public function test()
	{
		echo 'inside TestObject1 test function<hr>';
		print_r(Registry::ins()->get('model1'));
		unset(Registry::ins()->get('model1')->params_next);
		print_r(Registry::ins()->get('model1')->params);
		
		//print_r(RegisterGlobal::ins()->model->params);exit;
	}
}
?>