<?php
require_once('Registry.php');
abstract class Model
{
	protected $name;
	public function __construct()
	{
		$this->name = $this->className();
	}
	abstract function className();
	
	public function __get($name)
	{
		return $this->$name;
	}
}
?>